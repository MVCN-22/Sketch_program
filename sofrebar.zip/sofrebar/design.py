"""From the required reinforcement of each element to the bars chosen: a base mesh per area and layer, and top-up zones
where the elements need more. EN 1992-1-1 with the recommended values (use your National Annex where it differs)."""
import math
from . import geom as G
from .cdb import LAYERS, CODES

FCTK = {"C12/15": 1.1, "C16/20": 1.3, "C20/25": 1.5, "C25/30": 1.8, "C30/37": 2.0, "C35/45": 2.2, "C40/50": 2.5, "C45/55": 2.7,
        "C50/60": 2.9, "C55/67": 3.0, "C60/75": 3.1, "C70/85": 3.2, "C80/95": 3.4, "C90/105": 3.5}     # f_ctk,0.05, Table 3.1


class Settings:
    """what the design needs besides the model; every value has a default"""
    def __init__(self, cover=35.0, diameters=(8, 10, 12, 14, 16, 20, 25), spacings=(100, 125, 150, 175, 200, 250),
                 coverage="auto", zone_cost=10.0, as_min="EN", concrete="C30/37", fyk=500.0, gamma_c=1.5, gamma_s=1.15, alpha_ct=1.0,
                 lap_share=50.0, stock=12000.0, base=None, use_para=True):
        self.cover = float(cover); self.ds = sorted(set(float(d) for d in diameters)); self.ss = sorted(set(float(s) for s in spacings))
        try: self.coverage = min(1.0, max(0.0, float(coverage)))         # the share of the area the base mesh covers
        except (TypeError, ValueError): self.coverage = None             # "auto": the base mesh that needs the least steel
        self.zone_cost = float(zone_cost); self.as_min = as_min
        self.concrete = concrete if concrete in FCTK else "C30/37"; self.fyk = float(fyk)
        self.gamma_c = float(gamma_c); self.gamma_s = float(gamma_s); self.alpha_ct = float(alpha_ct)
        self.lap_share = float(lap_share); self.stock = float(stock)
        self.base = base or {}                             # fixed base meshes: {(sar or "all", layer index): (Ø, s)}
        self.use_para = use_para                           # BEMESS's basic reinforcement (PARA, from the .cdb) as the base mesh

    @property
    def fck(self): return float(self.concrete[1:].split("/")[0])


def as_of(d, s): return math.pi * d * d / 4 / s * 10          # cm²/m of Ø d at spacing s [mm]


def pick(req, ds, ss, fix_d=None, fix_s=None):
    """the bars with the least steel that give req cm²/m (then the wider spacing); (Ø, s, provided, enough)"""
    best = most = None
    for d in ([fix_d] if fix_d else ds):
        for s in ([fix_s] if fix_s else ss):
            a = as_of(d, s)
            if most is None or a > most[2]: most = (d, s, a)
            if a + 1e-9 >= req and (best is None or a < best[2] - 1e-9 or (abs(a - best[2]) < 1e-9 and s > best[1])): best = (d, s, a)
    return (best + (True,)) if best else (most + (False,))


def anchorage(S, d, good=True):
    """l_bd and l_0 [mm] for a straight bar in tension, fully stressed (8.4.3, 8.4.4, 8.7.3) with α1…α5 = 1 (on the safe side)"""
    eta1 = 1.0 if good else 0.7; eta2 = 1.0 if d <= 32 else (132 - d) / 100
    fctd = S.alpha_ct * min(FCTK[S.concrete], FCTK["C60/75"]) / S.gamma_c
    fbd = 2.25 * eta1 * eta2 * fctd; sigma = S.fyk / S.gamma_s
    lbrqd = d / 4 * sigma / fbd
    lbd = max(lbrqd, 0.3 * lbrqd, 10 * d, 100)
    a6 = min(1.5, max(1.0, math.sqrt(S.lap_share / 25)))
    l0 = max(a6 * lbrqd, 0.3 * a6 * lbrqd, 15 * d, 200)
    return math.ceil(lbd / 10) * 10, math.ceil(l0 / 10) * 10


def mandrel(d): return (4 if d <= 16 else 7) * d                # Table 8.1N


def layer_dir(A, k):
    """the bar direction of layer k in the area's plane, and the direction across the bars"""
    a = A.x if k % 2 == 0 else A.y
    return a, G.cross(A.z, a)


def smax(A, k):
    """the largest spacing: slabs 9.3.1.1(3) (principal 3h ≤ 400, secondary 3.5h ≤ 450), walls 9.6.2, 9.6.3 (3h ≤ 400)"""
    h = A.t
    if A.horizontal: return min(3 * h, 400) if k % 2 == 0 else min(3.5 * h, 450)
    return min(3 * h, 400)


def as_min(S, A, k):
    """minimum reinforcement per face [cm²/m]: slabs 9.2.1.1 / 9.3.1.1(2), walls 9.6.2(1) and 9.6.3(1)"""
    if S.as_min not in ("EN", None, ""):
        try: return float(S.as_min)
        except (TypeError, ValueError): return 0.0
    t = A.t; d = t - S.cover - 12
    fctm = 0.3 * S.fck ** (2 / 3) if S.fck <= 50 else 2.12 * math.log(1 + (S.fck + 8) / 10)
    if A.horizontal:
        main = max(0.26 * fctm / S.fyk, 0.0013) * 1000 * d / 100
        return main if k % 2 == 0 else 0.2 * main
    vert = 0.002 * t * 1000 / 100 / 2                               # 0.2 % of A_c, both faces together
    vertical_bars = abs(G.dot(layer_dir(A, k)[0], (0, 0, 1))) >= 0.5
    return vert if vertical_bars else max(0.25 * vert, 0.001 * t * 1000 / 100 / 2)


def good_bond(A, k, S):
    """Fig. 8.2 simplified: the upper bars of slabs thicker than 250 mm are in poor bond, all other bars good"""
    if not A.horizontal: return True
    upper = G.dot(G.mul(A.z, -1), (0, 0, 1)) > 0
    return not ((k < 2) == upper and A.t > 250)


def para_layer(P, k):
    """BEMESS's basic reinforcement for layer k (in local x / y order): (Ø, cm²/m) or None. The first layer of a face is its
    main bars, at DIRE UPP / LOW from local x"""
    if not P: return None
    from .cdb import along_y
    up = k < 2; y = along_y(P["dire"]["UPP" if up else "LOW"]); main = (k % 2 == 1) == y
    d, a = (P["DU"], P["ASU"]) if up and main else (P["DU2"], P["ASU2"]) if up else (P["DL"], P["ASL"]) if main else (P["DL2"], P["ASL2"])
    return (d, a) if a and d else None


class Layout:
    def __init__(self, M, S):
        self.M, self.S = M, S; self.base = {}; self.zones = []; self.notes = list(M.notes)


def design(M, S, zone_polys=None):
    """zone_polys: {sar: [ring in the area's 2D coordinates]} drawn by the user; they replace the automatic zones they cover"""
    L = Layout(M, S)
    zone_polys = zone_polys or {}
    for sar, A in sorted(M.areas.items()):
        for k in range(4):
            a, p = layer_dir(A, k)
            req = [(e.req[k], e.a, e) for e in A.els]
            amin = as_min(S, A, k)
            fixed = S.base.get((sar, k)) or S.base.get(("all", k))
            pa = para_layer(M.para_of(A.grp), k) if S.use_para and hasattr(M, "para_of") else None
            src = "fixed" if fixed else "PARA" if pa else "least steel"
            if fixed:
                d, s = fixed; prov = as_of(d, s); ok = True
            elif pa:                                       # the group's basic reinforcement, its Ø, at the widest spacing that gives it
                ss = [s for s in S.ss if s <= smax(A, k) + 1e-6] or [min(S.ss)]
                d, s, prov, ok = pick(max(pa[1], amin), S.ds, ss, fix_d=pa[0])
            else:
                ss = [s for s in S.ss if s <= smax(A, k) + 1e-6] or [min(S.ss)]
                if S.coverage is None:
                    d, s, prov, ok = _cheapest(A, k, S, ss, amin)
                else:
                    tot = sum(w for _, w, _ in req) or 1.0
                    acc, target = 0.0, 0.0
                    for r, w, _ in sorted(req, key=lambda t: t[0]):
                        acc += w
                        target = r
                        if acc >= S.coverage * tot - 1e-9: break
                    d, s, prov, ok = pick(max(target, amin), S.ds, ss)
            lbd, l0 = anchorage(S, d, good_bond(A, k, S))
            L.base[(sar, k)] = {"sar": sar, "layer": k, "d": d, "s": s, "prov": prov, "min": amin, "max": max(r for r, _, _ in req) if req else 0.0,
                                "lbd": lbd, "l0": l0, "good": good_bond(A, k, S), "src": src, "para": pa[1] if pa else None}
            if not ok: L.notes.append("SAR %d %s: the bar lists give at most %.2f cm²/m for the base mesh" % (sar, LAYERS[k], prov))
            _zones(L, A, k, a, p, prov, d, s, zone_polys.get(sar) or [])
    return L


def _groups(els):
    """elements in connected groups (sharing a node)"""
    by_node = {}
    for e in els:
        for n in e.nodes:
            if n: by_node.setdefault(n, []).append(e)
    seen, out = set(), []
    for e0 in els:
        if e0.nr in seen: continue
        comp, stack = [], [e0]; seen.add(e0.nr)
        while stack:
            e = stack.pop(); comp.append(e)
            for n in e.nodes:
                for f in by_node.get(n, []):
                    if f.nr not in seen: seen.add(f.nr); stack.append(f)
        out.append(comp)
    return out


def _cheapest(A, k, S, ss, amin):
    """the base mesh that needs the least steel with its top-up zones: [cm²/m · m²] of the mesh over the area, of the
    top-ups over the elements that need them (×1.3 for running l_bd past the zones), and S.zone_cost per zone for the work"""
    tot = sum(e.a for e in A.els); best = None
    for d in S.ds:
        for s in ss:
            prov = as_of(d, s)
            if prov + 1e-9 < amin: continue
            over = [e for e in A.els if e.req[k] > prov + 1e-6]
            cost, ok = prov * tot, True
            for e in over:
                td, ts, tp, tok = pick(e.req[k] - prov, S.ds, [s, 2 * s])
                cost += 1.3 * tp * e.a; ok = ok and tok
            if over: cost += S.zone_cost * len(_groups(over))
            if not ok: cost += 1e6
            if best is None or cost < best[0] - 1e-9: best = (cost, d, s, prov, ok)
    if best is None: return pick(amin, S.ds, ss)
    return best[1], best[2], best[3], best[4]


def _zones(L, A, k, a, p, base_prov, bd, bs, drawn):
    S = L.S
    to = lambda P: (G.dot(G.sub(P, A.O), a), G.dot(G.sub(P, A.O), p))      # along the bars, across them
    over = [e for e in A.els if e.req[k] > base_prov + 1e-6]
    picked = []
    # drawn zones: their outline, what the elements inside need
    for i, ring in enumerate(drawn):
        r2 = [to(A.at(u, v)) for u, v in ring]
        inside = [e for e in A.els if G.inside([ring], A.to2(e.c))]
        if not inside:
            if k == 0: L.notes.append("a zone drawn on SAR %d holds no element centre: make it larger" % A.sar)
            continue
        picked.append({"ring": r2, "els": inside, "drawn": True})
    taken = {e.nr for z in picked for e in z["els"]}
    # automatic zones: the elements that need more, in connected groups, as rectangles along the bars
    for comp in _groups([e for e in over if e.nr not in taken]):
        q = [to(P) for e in comp for P in e.pts]
        u0, v0, u1, v1 = G.bbox2(q)
        picked.append({"ring": [(u0, v0), (u1, v0), (u1, v1), (u0, v1)], "els": comp, "drawn": False})
    # rectangles that overlap become one
    merged = True
    while merged:
        merged = False
        for i in range(len(picked)):
            for j in range(i + 1, len(picked)):
                zi, zj = picked[i], picked[j]
                if zi["drawn"] or zj["drawn"]: continue
                a0, b0, a1, b1 = G.bbox2(zi["ring"]); c0, d0, c1, d1 = G.bbox2(zj["ring"])
                if a0 <= c1 and c0 <= a1 and b0 <= d1 and d0 <= b1:
                    u0, v0, u1, v1 = min(a0, c0), min(b0, d0), max(a1, c1), max(b1, d1)
                    zi["ring"] = [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]; zi["els"] = zi["els"] + zj["els"]
                    picked.pop(j); merged = True; break
            if merged: break
    for z in picked:
        zreq = max(e.req[k] for e in z["els"])
        if zreq <= base_prov + 1e-6:
            if z["drawn"] and k == 0: L.notes.append("a zone drawn on SAR %d: the base meshes there are enough, no top-up needed" % A.sar)
            continue
        need = zreq - base_prov
        d, s, prov, ok = pick(need, S.ds, [bs, 2 * bs])                  # between the base bars: every gap, or every other one
        lbd, l0 = anchorage(S, d, good_bond(A, k, S))
        n = sum(1 for q in L.zones if q["sar"] == A.sar and q["layer"] == k) + 1
        Z = {"sar": A.sar, "layer": k, "name": "Z%d.%s%d" % (A.sar, CODES[k], n), "ring": z["ring"], "drawn": z["drawn"],
             "req": zreq, "need": need, "d": d, "s": s, "prov": prov, "total": base_prov + prov, "ok": ok, "lbd": lbd, "l0": l0,
             "els": [e.nr for e in z["els"]], "area_m2": sum(e.a for e in z["els"])}
        L.zones.append(Z)
        if not ok: L.notes.append("%s (SAR %d %s): needs %.2f cm²/m; base %.2f + top-up Ø%g/%g = %.2f is not enough: choose a heavier base mesh" % (Z["name"], A.sar, LAYERS[k], zreq, base_prov, d, s, base_prov + prov))
