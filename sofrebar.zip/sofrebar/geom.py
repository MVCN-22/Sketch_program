"""Small vector and polygon helpers (pure Python, so the same code runs in Rhino 8 and in plain CPython for tests)."""
import math


def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def norm(a): return math.sqrt(dot(a, a))
def dist(a, b): return norm(sub(a, b))


def unit(a):
    n = norm(a)
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def along(P, d, t): return add(P, mul(d, t))


def polyline_length(pts): return sum(dist(pts[i - 1], pts[i]) for i in range(1, len(pts)))


# ---------------------------------------------------------------- 2D polygons (lists of (u, v))
def area2(ring):
    s = 0.0
    for i in range(len(ring)):
        x0, y0 = ring[i]; x1, y1 = ring[(i + 1) % len(ring)]
        s += x0 * y1 - x1 * y0
    return s / 2


def inside(rings, q):
    """even-odd point in polygon (outer ring and holes)"""
    x, y = q; c = False
    for r in rings:
        n = len(r)
        for i in range(n):
            x0, y0 = r[i]; x1, y1 = r[(i + 1) % n]
            if (y0 > y) != (y1 > y) and x < x0 + (y - y0) * (x1 - x0) / (y1 - y0): c = not c
    return c


def dist_to_rings(rings, q):
    """distance from a point to the nearest edge"""
    best = float("inf")
    for r in rings:
        n = len(r)
        for i in range(n):
            a = r[i]; b = r[(i + 1) % n]
            vx, vy = b[0] - a[0], b[1] - a[1]; L2 = vx * vx + vy * vy
            t = max(0.0, min(1.0, ((q[0] - a[0]) * vx + (q[1] - a[1]) * vy) / L2)) if L2 else 0.0
            best = min(best, math.hypot(q[0] - a[0] - vx * t, q[1] - a[1] - vy * t))
    return best


def line_segments(rings, v):
    """the parts of the horizontal line y = v inside the polygon: [(u0, u1, edge0, edge1)], edges as (ring, index)"""
    hits = []
    for ri, r in enumerate(rings):
        n = len(r)
        for i in range(n):
            x0, y0 = r[i]; x1, y1 = r[(i + 1) % n]
            if (y0 > v) != (y1 > v):
                hits.append((x0 + (v - y0) * (x1 - x0) / (y1 - y0), (ri, i)))
    hits.sort(key=lambda h: h[0])
    return [(hits[k][0], hits[k + 1][0], hits[k][1], hits[k + 1][1]) for k in range(0, len(hits) - 1, 2)]


def simplify(ring, tol=1e-6):
    """leave out points on a straight line between their neighbours"""
    out = list(ring)
    changed = True
    while changed and len(out) > 3:
        changed = False
        for i in range(len(out)):
            a = out[i - 1]; b = out[i]; c = out[(i + 1) % len(out)]
            cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
            if abs(cr) <= tol * max(1.0, math.hypot(c[0] - a[0], c[1] - a[1])):
                out.pop(i); changed = True; break
    return out


def bbox2(pts):
    us = [p[0] for p in pts]; vs = [p[1] for p in pts]
    return min(us), min(vs), max(us), max(vs)
