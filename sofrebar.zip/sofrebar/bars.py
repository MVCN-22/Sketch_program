"""The bars of a layout: base meshes and zone top-ups, with their ends worked out where an area meets another one.

At a bar end the edge it reaches is either free (the bar stops at the cover) or shared with other areas (found from
the nodes SOFiSTiK's mesh shares there). How the bar crosses a junction, by the angle between the areas or as set:
  through  (in one plane, < 5°)   the bars of the area with the higher number run on by l0 and lap
  kink     (5° to 45°)            they bend at the joint and run on by l0 along the other area
  anchor   (steeper)              they run to the far face of the other area and turn along it, with a leg so that
                                  l_bd is reached (at least 10 Ø past the bend)
  joint    (set by the user)      no bars across: the edge is free
Every way is checked to stay in the concrete (with half the cover to spare); if none does, the bar stops at the cover.
"""
import math
from . import geom as G
from .cdb import LAYERS
from .design import layer_dir, anchorage, good_bond, mandrel

MODES = ("auto", "through", "anchor", "joint")


class Bar:
    __slots__ = ("pts", "d", "s", "sar", "layer", "kind", "zone", "ends", "mark", "shape", "length", "piece")
    def __init__(self, pts, d, s, sar, layer, kind, zone=None, ends=("", "")):
        self.pts, self.d, self.s, self.sar, self.layer, self.kind, self.zone, self.ends = pts, d, s, sar, layer, kind, zone, ends
        self.mark = 0; self.piece = 0
        self.length = math.ceil(G.polyline_length(pts) / 10) * 10
        bends = len(pts) - 2
        self.shape = "straight" if bends <= 0 else "%d bend%s" % (bends, "" if bends == 1 else "s")


class Result:
    def __init__(self):
        self.bars = []; self.junctions = []; self.notes = []; self.schedule = []


def node_areas(M):
    m = {}
    for sar, A in M.areas.items():
        for n in A.nodes: m.setdefault(n, set()).add(sar)
    return m


def corners(M, na=None):
    """the concrete past the mesh at junctions: SOFiSTiK's areas end at each other's mid-surface, the concrete runs on to the
    other area's face. Each area gets its shared edges (in its own 2D coordinates) with half the other area's thickness."""
    na = na or node_areas(M)
    for A in M.areas.values():
        A.jx = []
        for (n1, n2) in A.edges:
            others = (na.get(n1, set()) & na.get(n2, set())) - {A.sar}
            if others: A.jx.append((A.to2(M.nodes[n1]), A.to2(M.nodes[n2]), max(M.areas[o].t for o in others) / 2))


def in_conc(A, X, m):
    """is X in the concrete of area A, at least m inside its faces (corners() adds the concrete past shared edges)"""
    d = G.sub(X, A.O)
    w = G.dot(d, A.z)
    if abs(w) > A.t / 2 - m + 1e-6: return False
    q = (G.dot(d, A.x), G.dot(d, A.y))
    if G.inside(A.rings, q) or G.dist_to_rings(A.rings, q) < 1.0: return True     # on an edge it shares with the next area: concrete too
    for (a, b, ext) in getattr(A, "jx", ()):
        ex, ey = b[0] - a[0], b[1] - a[1]; L2 = ex * ex + ey * ey
        if L2 < 1e-9: continue
        f = ((q[0] - a[0]) * ex + (q[1] - a[1]) * ey) / L2
        if -1e-6 <= f <= 1 + 1e-6 and abs((q[0] - a[0]) * ey - (q[1] - a[1]) * ex) / math.sqrt(L2) <= ext - m + 1e-6: return True
    return False


def angle(A, B): return math.degrees(math.acos(min(1.0, abs(G.dot(A.z, B.z)))))


def build(M, L, conn=None):
    """conn: {(sar1, sar2): mode} for junctions set by hand (sar1 < sar2)"""
    S = L.S; R = Result(); conn = conn or {}
    na = node_areas(M)
    corners(M, na)
    seen = set()
    for sar, A in M.areas.items():                          # the junctions, once each
        for (n1, n2) in A.edges:
            for o in (na.get(n1, set()) & na.get(n2, set())) - {sar}:
                key = (min(sar, o), max(sar, o))
                if key in seen: continue
                seen.add(key)
                mode = conn.get(key, "auto")
                R.junctions.append({"sars": key, "angle": angle(A, M.areas[o]), "mode": mode})
    jmode = {j["sars"]: j["mode"] for j in R.junctions}
    for sar, A in sorted(M.areas.items()):
        if A.warp > 5: R.notes.append("SAR %d is curved or warped (%.0f mm out of plane): its bars follow its average plane" % (sar, A.warp))
        depth = _depths(L, A)
        for k in range(4):
            B = L.base[(sar, k)]
            _layer(M, L, R, A, k, B["d"], B["s"], depth[k], B, None, na, jmode)
        for Z in [z for z in L.zones if z["sar"] == sar]:
            _layer(M, L, R, A, Z["layer"], Z["d"], Z["s"], depth[Z["layer"]], L.base[(sar, Z["layer"])], Z, na, jmode)
    _laps(R, S, L)
    _marks(R)
    return R


def _depths(L, A):
    """the depth of each layer below its face: the cross bars outside, the principal bars inside them"""
    c = L.S.cover; d = lambda k: L.base[(A.sar, k)]["d"]
    return {1: c + d(1) / 2, 0: c + d(1) + d(0) / 2, 3: c + d(3) / 2, 2: c + d(3) + d(2) / 2}


def _layer(M, L, R, A, k, d, s, depth, base, Z, na, jmode):
    S = L.S; c = S.cover
    a, p = layer_dir(A, k)
    w = (-A.t / 2 + depth) if k < 2 else (A.t / 2 - depth)          # upper face against local z
    to = lambda P: (G.dot(G.sub(P, A.O), a), G.dot(G.sub(P, A.O), p))
    rings = [[to(M.nodes[n]) for n in loop] for loop in A.loops]
    P3 = lambda u, v: G.add(A.O, G.add(G.mul(a, u), G.add(G.mul(p, v), G.mul(A.z, w))))
    allv = [q[1] for q in rings[0]]
    v0, v1 = min(allv) + c + d / 2, max(allv) - c - d / 2
    bs = base["s"]
    n = int(math.floor((v1 - v0) / bs + 1e-9)); start = (v0 + v1 - n * bs) / 2      # the base bars, centred
    if Z is None: vs = [start + i * s for i in range(n + 1)]
    else:                                                             # zone bars between the base bars, in the zone
        zv0, zv1 = min(q[1] for q in Z["ring"]), max(q[1] for q in Z["ring"])
        step = int(round(s / bs))
        vs = [start + (i + 0.5) * bs for i in range(n) if i % step == 0]
        vs = [v for v in vs if zv0 - 1e-6 <= v <= zv1 + 1e-6] or ([(zv0 + zv1) / 2] if zv1 - zv0 < bs else [])
    lbd, l0 = anchorage(S, d, good_bond(A, k, S))
    for i, v in enumerate(vs):
        segs = G.line_segments(rings, v)
        if Z is not None:                                             # the zone along the bar, l_bd past it each way, inside the area
            zs = G.line_segments([Z["ring"]], v)
            if not zs:
                u0, _, u1, _ = G.bbox2(Z["ring"]); zs = [(u0, u1, None, None)]
            cut = []
            for (zu0, zu1, _, _) in zs:
                lo, hi = zu0 - lbd, zu1 + lbd
                for (su0, su1, e0, e1) in segs:
                    if su1 < lo or su0 > hi: continue
                    cut.append((max(su0, lo), min(su1, hi), e0 if lo <= su0 else None, e1 if hi >= su1 else None))
            segs = cut
        for (u0, u1, e0, e1) in segs:
            if u1 - u0 < 2 * d: continue
            head, s0 = _end(M, A, k, a, p, u0, v, w, e0, -1, d, lbd, l0, rings, na, jmode, c)
            tail, s1 = _end(M, A, k, a, p, u1, v, w, e1, +1, d, lbd, l0, rings, na, jmode, c)
            pts = [P3(*q) if len(q) == 2 else q for q in head[::-1]] + [P3(*q) if len(q) == 2 else q for q in tail]
            pts = [q for j, q in enumerate(pts) if j == 0 or G.dist(q, pts[j - 1]) > 1]
            if len(pts) < 2 or G.polyline_length(pts) < 4 * d: continue
            R.bars.append(Bar(pts, d, s, A.sar, k, "zone" if Z else "base", Z["name"] if Z else None, (s0, s1)))


def _end(M, A, k, a, p, u, v, w, edge, sg, d, lbd, l0, rings, na, jmode, c):
    """the end of a bar at u: [points from the end inwards...], how it ends. A point is (u, v) in the layer or a 3D point"""
    if edge is None: return [(u, v)], "in the zone"
    ri, i = edge
    loop = A.loops[ri]; n1, n2 = loop[i], loop[(i + 1) % len(loop)]
    E1, E2 = M.nodes[n1], M.nodes[n2]
    e2 = (G.dot(G.sub(E2, E1), a), G.dot(G.sub(E2, E1), p)); el = math.hypot(*e2) or 1
    sin = abs(e2[1]) / el                                             # the angle between the bar and the edge
    nbs = [M.areas[o] for o in (na.get(n1, set()) & na.get(n2, set())) - {A.sar}]
    free = [(u - sg * min(c / max(sin, 0.2), 3 * c), v)]
    if not nbs: return free, "free edge"
    P3 = lambda uu: G.add(A.O, G.add(G.mul(a, uu), G.add(G.mul(p, v), G.mul(A.z, w))))
    E = P3(u); dirb = G.mul(a, sg)
    best = max(nbs, key=lambda B: angle(A, B))                         # the most perpendicular neighbour
    mode = jmode.get((min(A.sar, best.sar), max(A.sar, best.sar)), "auto")
    if mode == "joint": return free, "joint"
    ang = angle(A, best); m = c / 2
    ok = lambda pts: all(any(in_conc(B, X, m) for B in [A] + nbs) for X in _samples([E] + pts))
    back = [(u - sg * d / 2, v)]                                       # just inside its own area, where the other area's bars lap it
    # the other area's bars run on into this one by l0: only if there is room for them here (else this side anchors itself)
    room = lambda: ok([G.along(E, dirb, -l0)])
    def straight():
        if ang >= 5: return None                                       # a straight lap only in one plane
        if A.sar < best.sar: return (back, "lapped (the other area runs on)") if room() else None
        P = G.along(E, dirb, l0)
        return ([(u, v), P], "lapped by l0") if ok([P]) else None
    def kink():
        if A.sar < best.sar:
            if math.cos(math.radians(ang)) < 0.3: return None               # too steep for the other bars to bend into this area
            return (back, "lapped (the other area runs on)") if room() else None
        g = G.sub(dirb, G.mul(best.z, G.dot(dirb, best.z)))
        if G.norm(g) < 0.3: return None
        g = G.unit(g)
        s0 = G.dot(G.sub(E, best.O), best.z)                          # the bar's offset in the other area, kept inside it
        lim = best.t / 2 - c - d / 2
        K = E if abs(s0) <= lim else G.sub(E, G.mul(best.z, s0 - math.copysign(lim, s0)))
        P = G.along(K, g, l0)
        return ([(u, v), K, P], "bent at the kink, lapped by l0") if ok([K, P]) else None
    def anchor():
        bn = G.dot(dirb, best.z)
        if abs(bn) < 0.25: return None
        s0 = G.dot(G.sub(E, best.O), best.z)
        side = 1 if G.dot(G.sub(A.at(*_mid(A)), best.O), best.z) > 0 else -1   # the side of the other area this one is on
        target = -side * (best.t / 2 - c - d / 2)                      # its far face, less the cover
        t = (target - s0) / bn
        if not (t > 0) or t > 3 * best.t + 300: return None
        K = G.along(E, dirb, t)
        if not ok([K]): return None
        e3 = G.unit(G.sub(E2, E1)); g0 = G.unit(G.cross(best.z, e3))
        R0 = mandrel(d) / 2 + d / 2; need = max(lbd - t, 10 * d) + R0
        legs = []
        for g in (g0, G.mul(g0, -1)):
            av = 0.0
            while av < need and in_conc(best, G.along(K, g, av + 25), c + d / 2 - 1): av += 25
            legs.append((av, g))
        av, g = max(legs, key=lambda q: q[0])
        if av >= 10 * d + R0:
            leg = min(need, av)
            return [(u, v), K, G.along(K, g, leg)], "anchored, bent (leg %d)" % (math.ceil(leg / 10) * 10)
        return [(u, v), K], "anchored, straight to the far face"
    tries = {"through": (straight, kink, anchor), "anchor": (anchor,)}.get(mode) or ((straight, kink) if ang < 5 else (kink, anchor) if ang < 45 else (anchor,))
    for f in tries:
        r = f()
        if r: return r
    return free, "stopped at the cover (no room to anchor)"


def _mid(A):
    u0, v0, u1, v1 = G.bbox2(A.rings[0])
    for q in [((u0 + u1) / 2, (v0 + v1) / 2)] + [(sum(p[0] for p in A.rings[0]) / len(A.rings[0]), sum(p[1] for p in A.rings[0]) / len(A.rings[0]))]:
        if G.inside(A.rings, q): return q
    e = A.els[0]; return A.to2(e.c)


def _samples(pts, step=25.0):
    out = []
    for i in range(1, len(pts)):
        a, b = pts[i - 1], pts[i]; n = max(1, int(math.ceil(G.dist(a, b) / step)))
        out += [G.add(a, G.mul(G.sub(b, a), j / n)) for j in range(1, n + 1)]
    return out


def _sub(pts, s0, s1):
    """the part of a polyline between two lengths along it"""
    out, run = [], 0.0
    for i in range(1, len(pts)):
        a, b = pts[i - 1], pts[i]; L = G.dist(a, b)
        if L <= 0: continue
        lo, hi = max(s0, run), min(s1, run + L)
        if hi > lo:
            pa = G.add(a, G.mul(G.sub(b, a), (lo - run) / L)); pb = G.add(a, G.mul(G.sub(b, a), (hi - run) / L))
            if not out or G.dist(out[-1], pa) > 1e-6: out.append(pa)
            out.append(pb)
        run += L
    return out


def _laps(R, S, L):
    """runs longer than the stock length: bars of the stock length, each lapped by l0 with the next; every other run starts
    with a half bar, so that no more than half the bars are lapped in one place"""
    out, count = [], {}
    for b in R.bars:
        Lb = G.polyline_length(b.pts)
        if Lb <= S.stock + 1:
            out.append(b); continue
        _, l0 = anchorage(S, b.d, good_bond(L.M.areas[b.sar], b.layer, S))
        if S.stock - l0 <= 0.3 * l0:
            out.append(b); R.notes.append("Ø%g bars of %g mm are too short to lap by %g mm" % (b.d, S.stock, l0)); continue
        key = (b.sar, b.layer, b.kind, b.zone); j = count.get(key, 0); count[key] = j + 1
        first = S.stock / 2 if (j % 2 and S.stock / 2 > 1.5 * l0) else S.stock
        a0, q = 0.0, 0
        while True:
            a1 = min(Lb, a0 + (first if q == 0 else S.stock))
            seg = _sub(b.pts, a0, a1)
            if len(seg) >= 2:
                nb = Bar(seg, b.d, b.s, b.sar, b.layer, b.kind, b.zone, (b.ends[0] if q == 0 else "lapped", b.ends[1] if a1 >= Lb - 1e-6 else "lapped"))
                nb.piece = q + 1; out.append(nb)
            if a1 >= Lb - 1e-6: break
            a0, q = a1 - l0, q + 1
    R.bars = out


def _marks(R):
    """equal Ø, length and shape share a mark"""
    groups = {}
    for b in R.bars:
        groups.setdefault((b.d, b.length, b.shape), []).append(b)
    keys = sorted(groups, key=lambda k: (-k[0], k[2] != "straight", -k[1]))
    for i, k in enumerate(keys):
        for b in groups[k]: b.mark = i + 1
        bs = groups[k]
        R.schedule.append({"mark": i + 1, "d": k[0], "length": k[1], "shape": k[2], "n": len(bs),
                           "kg": len(bs) * k[1] / 1000 * k[0] ** 2 / 162.2, "where": sorted({b.sar for b in bs})})
