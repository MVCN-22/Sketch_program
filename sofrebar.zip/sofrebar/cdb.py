"""Reading a SOFiSTiK database (.cdb) through SOFiSTiK's own CDB interface (sof_cdb_w-<version>.dll, installed with SOFiSTiK).

What is read (all documented CDB records):
  20/00    nodes (coordinates)
  200/00   QUAD elements: nodes, thickness, local axes; the structural area (SAR) an element belongs to is in the upper
           bits of its element type (m_nra >> 13)
  10/00    the group divisor; 11/00 the element numbers of each group
  200/6    BEMESS's design parameters per group (PARA, DIRE, GEOM): the direction of the main bars, the diameters, the
           basic (minimum) reinforcement, where the layers lie
  260/DC   design results of the QUADs (BEMESS): required reinforcement upper/lower in the principal and cross direction
           (stored in m²/m like every CDB value in SI units; given here in cm²/m)
  270/DC   reinforcement layer design results (newer design); the layers are taken from their definitions in 270/0
The file is opened read-only; nothing is written.
"""
import os, glob, math, struct
from ctypes import cdll, c_int, byref, sizeof, create_string_buffer
from . import geom as G

LAYERS = ("upper principal", "upper cross", "lower principal", "lower cross")
CODES = ("UP", "UC", "LP", "LC")                                  # short names of the layers
AS_UNIT = 1e4                                                      # the CDB holds SI units: m²/m; here cm²/m
FACE_OF = {0: "upper", 1: "upper", 2: "lower", 3: "lower"}


def find_dll():
    """the newest installed SOFiSTiK CDB interface: (dll path, folders to add)"""
    roots = sorted(glob.glob(r"C:\Program Files\SOFiSTiK\20*"), reverse=True)
    for r in roots:
        year = os.path.basename(r)
        prog = os.path.join(r, "SOFiSTiK " + year)
        dll = os.path.join(prog, "interfaces", "64bit", "sof_cdb_w-%s.dll" % year)
        if os.path.exists(dll):
            return dll, [os.path.join(prog, "interfaces", "64bit"), prog]
    raise RuntimeError("SOFiSTiK is not installed on this PC (no sof_cdb_w-*.dll under C:\\Program Files\\SOFiSTiK)")


class Cdb:
    def __init__(self, path):
        if not os.path.exists(path): raise IOError("no such file: %s" % path)
        dll, dirs = find_dll()
        for d in dirs:
            try: os.add_dll_directory(d)
            except Exception: pass
        os.environ["PATH"] = ";".join(dirs) + ";" + os.environ.get("PATH", "")
        self.dll = cdll.LoadLibrary(dll)
        self.index = self.dll.sof_cdb_init(path.encode("utf-8"), 99)       # 99: read only
        if self.index < 0: raise IOError("SOFiSTiK could not open %s (code %d)" % (path, self.index))

    def close(self):
        try: self.dll.sof_cdb_close(0)
        except Exception: pass

    def exists(self, kwh, kwl): return self.dll.sof_cdb_kexist(kwh, kwl) == 2

    def records(self, kwh, kwl, size=8192):
        """all records of a key as raw bytes"""
        out = []
        while True:
            buf = create_string_buffer(size); n = c_int(size)
            ie = self.dll.sof_cdb_get(self.index, kwh, kwl, byref(buf), byref(n), 1)
            if ie >= 2: break
            out.append(buf.raw[:n.value])
        return out


def _ints(b, a, k): return struct.unpack_from("<%di" % k, b, 4 * a)
def _flts(b, a, k): return struct.unpack_from("<%df" % k, b, 4 * a)


class Element:
    __slots__ = ("nr", "sar", "grp", "nodes", "pts", "c", "a", "t", "req", "skew", "_x", "_z")
    def __init__(self, nr, sar, nodes, pts, t):
        self.nr, self.sar, self.nodes, self.pts, self.t = nr, sar, nodes, pts, t
        self.grp = None
        self.c = tuple(sum(p[k] for p in pts) / len(pts) for k in range(3))
        self.a = 0.0                                       # area in m², set with the area's frame
        self.req = [0.0, 0.0, 0.0, 0.0]                    # cm²/m per LAYERS: principal along local x, cross along local y
        self.skew = False                                  # the design gave other directions


class Area:
    """a structural area (SAR) as SOFiSTiK meshed it: frame, outline and openings, thickness, its elements"""
    def __init__(self, sar):
        self.sar = sar; self.els = []; self.nodes = set()

    def finish(self, nodes):
        from collections import Counter
        xs = Counter(); zs = {}
        for e in self.els:
            key = tuple(round(v, 4) for v in e._x + e._z)
            xs[key] += 1; zs[key] = (e._x, e._z)
        self.x, self.z = zs[xs.most_common(1)[0][0]]
        self.x = G.unit(self.x); self.z = G.unit(self.z); self.y = G.cross(self.z, self.x)
        self.t = sorted(e.t for e in self.els)[len(self.els) // 2]
        # the outline: element edges used once are on the boundary; chained into loops of node numbers
        cnt = Counter()
        for e in self.els:
            ns = [n for i, n in enumerate(e.nodes) if n and (i == 0 or n != e.nodes[i - 1])]
            if len(ns) > 1 and ns[0] == ns[-1]: ns = ns[:-1]
            for i in range(len(ns)):
                cnt[tuple(sorted((ns[i], ns[(i + 1) % len(ns)])))] += 1
        nb = {}
        for (a, b), k in cnt.items():
            if k == 1: nb.setdefault(a, []).append(b); nb.setdefault(b, []).append(a)
        used, loops = set(), []
        for a0 in sorted(nb):
            for b0 in nb[a0]:
                if (a0, b0) in used: continue
                loop, a, b = [a0], a0, b0
                while True:
                    used.add((a, b)); used.add((b, a))
                    if b == a0: break
                    loop.append(b)
                    nxt = [c for c in nb[b] if (b, c) not in used]
                    if not nxt: break
                    a, b = b, nxt[0]
                if len(loop) >= 3: loops.append(loop)
        self.O = nodes[loops[0][0]] if loops else self.els[0].c
        to2 = self.to2
        loops.sort(key=lambda L: -abs(G.area2([to2(nodes[n]) for n in L])))
        self.loops = loops                                 # outer first, then openings (node numbers)
        self.rings = [[to2(nodes[n]) for n in L] for L in loops]
        self.warp = max([abs(G.dot(G.sub(nodes[n], self.O), self.z)) for n in self.nodes] + [0.0])
        for e in self.els:
            q = [to2(p) for p in e.pts]
            e.a = abs(G.area2(q)) / 1e6
        self.edges = {tuple(sorted((L[i], L[(i + 1) % len(L)]))) for L in loops for i in range(len(L))}

    def to2(self, P):
        d = G.sub(P, self.O)
        return (G.dot(d, self.x), G.dot(d, self.y))

    def at(self, u, v, w=0.0):
        return G.add(self.O, G.add(G.mul(self.x, u), G.add(G.mul(self.y, v), G.mul(self.z, w))))

    @property
    def horizontal(self): return abs(self.z[2]) >= 0.5


class Model:
    def __init__(self):
        self.nodes = {}; self.areas = {}; self.cases = []; self.source = ""; self.notes = []; self.has_results = False
        self.para = {}                                     # BEMESS's parameters per group (-1: the default for all groups)

    def para_of(self, grp):
        return self.para.get(grp) or self.para.get(-1)


def read(path, case=None, units=1000.0, snapshot=True):
    """the model of a .cdb: units = mm per CDB length unit (SOFiSTiK stores metres: 1000); snapshot: read a copy, so the
    file SOFiSTiK works on is never opened (nor locked) here"""
    tmp = None
    if snapshot:
        import shutil, tempfile
        tmp = tempfile.mkdtemp(prefix="sofrebar_")
        shutil.copy2(path, os.path.join(tmp, "model.cdb"))
    db = Cdb(os.path.join(tmp, "model.cdb") if tmp else path)
    M = Model(); M.source = path
    try:
        for b in db.records(20, 0):
            if len(b) < 28: continue
            nr = _ints(b, 0, 1)[0]
            x, y, z = _flts(b, 4, 3)
            M.nodes[nr] = (x * units, y * units, z * units)
        els = {}
        for b in db.records(200, 0):
            if len(b) < 27 * 4: continue
            nr, n1, n2, n3, n4, mat, mrf, nra = _ints(b, 0, 8)
            th = _flts(b, 11, 5); t = _flts(b, 18, 9)
            ns = (n1, n2, n3, n4)
            if any(n and n not in M.nodes for n in ns): continue
            pts = [M.nodes[n] for n in ns if n]
            e = Element(nr, nra >> 13, ns, pts, th[0] * units)
            e._x = (t[0], t[1], t[2]); e._z = (t[6], t[7], t[8])
            els[nr] = e
        _groups(db, els)
        M.para = _para(db)
        for e in els.values():
            A = M.areas.get(e.sar) or M.areas.setdefault(e.sar, Area(e.sar))
            A.els.append(e); A.nodes.update(n for n in e.nodes if n)
        for A in M.areas.values():
            A.finish(M.nodes)
            gs = [e.grp for e in A.els if e.grp is not None]
            A.grp = max(set(gs), key=gs.count) if gs else None
        _results(db, M, els, case)
    finally:
        db.close()
        if tmp:
            import shutil
            shutil.rmtree(tmp, ignore_errors=True)
    return M


NA = -99998.0                                                      # SOFiSTiK writes -99999 for "not given"


def _groups(db, els):
    """the group of each element: from the groups' element ranges (11/00), else element number / group divisor (10/00)"""
    rng = []
    for b in db.records(11, 0):
        if len(b) >= 20: ng, typ, num, lo, hi = _ints(b, 0, 5); rng.append((lo, hi, ng))
    div = 0
    for b in db.records(10, 0):
        if len(b) >= 20: div = _ints(b, 4, 1)[0]; break
    for e in els.values():
        g = next((ng for lo, hi, ng in rng if lo <= e.nr <= hi), None)
        e.grp = g if g is not None else (e.nr // abs(div) if div else None)


def _para(db):
    """BEMESS's parameters per group (200/6), in mm, cm²/m and degrees, as the web program's BEMESS reader gives them:
    DU, DU2, DL, DL2, ASU, ASU2, ASL, ASL2, dire {UPP, LOW} (the main bars from local x), geom {HA, DHA, HB, DHB}"""
    out = {}
    for b in db.records(200, 6):
        if len(b) < 34 * 4: continue
        nrg = _ints(b, 0, 1)[0]
        f = _flts(b, 5, 29)                                            # rio … ass, in the order of CQUAD_RIM
        rio, rioq, rioi, riu, riuq, riui = f[0:6]; hio, hioq, hioi, hiu, hiuq, hiui = f[9:15]
        dio, dioq, dioi, diu, diuq, diui = f[15:21]; aso, asoq, asoi, asu, asuq, asui = f[22:28]
        ok = lambda v: v is not None and v > NA
        mm = lambda v: round(v * 1000, 1) if ok(v) else None
        cm = lambda v: round(v * AS_UNIT, 3) if ok(v) and v > 0 else None
        deg = lambda v: round(math.degrees(v), 3) if ok(v) else 0.0
        out[-1 if nrg < 0 else nrg] = {"DU": mm(dio), "DU2": mm(dioq), "DL": mm(diu), "DL2": mm(diuq),
            "ASU": cm(aso), "ASU2": cm(asoq), "ASL": cm(asu), "ASL2": cm(asuq),
            "dire": {"UPP": deg(rio), "LOW": deg(riu)},
            "geom": {"HA": mm(hio), "DHA": round((hioq - hio) * 1000, 1) if ok(hio) and ok(hioq) else None,
                     "HB": mm(hiu), "DHB": round((hiuq - hiu) * 1000, 1) if ok(hiu) and ok(hiuq) else None}}
    return out


def along_y(deg):
    """is a direction at deg from local x closer to local y?"""
    a = math.radians(deg or 0.0)
    return abs(math.sin(a)) > abs(math.cos(a)) + 1e-9


def _results(db, M, els, case):
    """the required reinforcement per element: the largest over the design cases (or the case asked for)"""
    c260 = [k for k in range(0, 10000) if db.exists(260, k)]
    c270 = [k for k in range(1, 10000) if db.exists(270, k)]
    M.cases = sorted(set(c260 + c270))
    use = lambda cs: [k for k in cs if case is None or k == case]
    n = 0
    for dc in use(c260):
        for b in db.records(260, dc):
            if len(b) < 14 * 4: continue
            nr = _ints(b, 0, 1)[0]; e = els.get(nr)
            if not e: continue
            aso, asoq, asu, asuq = (v * AS_UNIT for v in _flts(b, 1, 4))
            rio, rioq, riu, riuq = _flts(b, 10, 4)
            for k, v in enumerate((aso, asoq, asu, asuq)):
                if v > e.req[k]: e.req[k] = float(v)
            if abs(rio) > 1e-3 or abs(riu) > 1e-3: e.skew = True     # principal not along local x
            n += 1
    if not n and c270:
        # layer results: the layer definitions (270/0) give each layer's direction; order taken as SOFiSTiK lists them
        defs = []
        for b in db.records(270, 0):
            ident = _ints(b, 0, 1)[0]
            if ident != 0 and len(b) >= 12 and ident not in defs: defs.append(ident)
        slot = {ident: i for i, ident in enumerate(defs[:4])}
        for dc in use(c270):
            for b in db.records(270, dc):
                if len(b) < 20: continue
                ng, nr, ident, orig = _ints(b, 0, 4); aso = _flts(b, 4, 1)[0] * AS_UNIT
                e = els.get(nr)
                if not e or ident not in slot: continue
                k = slot[ident]
                e.req[k] = max(e.req[k], float(aso))
                n += 1
        if n: M.notes.append("design results from layer records (270): the layers are taken in the order SOFiSTiK defines them; check their faces once against SOFiSTiK's plot")
    if n:
        turned, skew = set(), set()
        for e in els.values():
            P = M.para_of(e.grp)
            if not P: continue
            u, l = P["dire"]["UPP"], P["dire"]["LOW"]
            if along_y(u): e.req[0], e.req[1] = e.req[1], e.req[0]; turned.add(e.grp)
            if along_y(l): e.req[2], e.req[3] = e.req[3], e.req[2]; turned.add(e.grp)
            if any(abs(math.sin(2 * math.radians(a))) > 0.17 for a in (u, l)): skew.add(e.grp)
        if turned: M.notes.append("groups %s: BEMESS's main bars run along local y (DIRE 90): the results are taken that way (here: principal = along local x, cross = along local y)" % ", ".join(map(str, sorted(turned))))
        if skew: M.notes.append("groups %s: BEMESS's main bars run at an angle to the local axes; the bars here follow local x and y" % ", ".join(map(str, sorted(skew))))
    M.has_results = n > 0
    sk = sorted({e.sar for e in els.values() if e.skew})
    if sk: M.notes.append("SAR %s: the design gives the reinforcement in other directions than the local axes; the bars here follow the local x and y axes" % ", ".join(map(str, sk)))
    if not n: M.notes.append("this .cdb holds no design results (records 260 or 270): run the ULS design for the shells in SOFiSTiK first")

